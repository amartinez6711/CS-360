import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.myapplication.R;

import java.util.List;

public class EventAdapter extends ArrayAdapter<EventDetails> {

    public EventAdapter(@NonNull Context context, int resource, @NonNull List<EventDetails> objects) {
        super(context, resource, objects);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View gridView = convertView;

        if (gridView == null){
            gridView = LayoutInflater.from(getContext()).inflate(R.layout.grid,parent, false);

        }
        TextView name = gridView.findViewById(R.id.textViewName);
        TextView desc = gridView.findViewById(R.id.textViewDetails);
        TextView date = gridView.findViewById((R.id.editTextDate));

        EventDetails currentEventDetails = getItem(position);
        name.setText(currentEventDetails.getName());
        desc.setText(currentEventDetails.getDescription());
        date.setText(currentEventDetails.getDate());

        return gridView;

    }
}
